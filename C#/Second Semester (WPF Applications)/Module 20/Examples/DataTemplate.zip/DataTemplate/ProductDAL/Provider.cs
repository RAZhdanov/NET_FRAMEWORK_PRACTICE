﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace ProductDAL
{
    public class Provider
    {
        const string FilePath = "ProductsData.xml";
        public static Product[] GetProducts()
        {
            List<Product> result = new List<Product>();

            XmlSerializer ser = new XmlSerializer(typeof(Product[]));
            StreamReader sr = new StreamReader(FilePath);
            Product[] products = (Product[])ser.Deserialize(sr);
            foreach (Product p in products)
            {
                p.ImageFilePath = Path.Combine(Environment.CurrentDirectory, p.ImageFilePath);
            }

            sr.Close();
            return products;
        }
        public static void SaveProducts(Product[] products)
        {
            XmlSerializer ser = new XmlSerializer(typeof(Product[]));
            StreamWriter sw = new StreamWriter(FilePath);
            ser.Serialize(sw, products);
            sw.Close();
        }
    }
}
