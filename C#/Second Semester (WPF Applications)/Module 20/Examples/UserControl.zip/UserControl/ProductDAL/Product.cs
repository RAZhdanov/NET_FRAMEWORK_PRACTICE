﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.ComponentModel;

namespace ProductDAL
{
    public class Product : INotifyPropertyChanged
    {
        #region Properties

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    RaisePropertyChanged("Name");
                }
            }
        }

        private string description;
        public string Description
        {
            get { return description; }
            set
            {
                if (description != value)
                {
                    description = value;
                    RaisePropertyChanged("Description");
                }
            }
        }

        private string imageFilePath;
        public string ImageFilePath
        {
            get { return imageFilePath; }
            set
            {
                if (imageFilePath != value)
                {
                    imageFilePath = value;
                    RaisePropertyChanged("ImageFilePath");
                }
            }
        }

        private decimal cost;
        public decimal Cost
        {
            get { return cost; }
            set
            {
                if (cost != value)
                {
                    cost = value;
                    RaisePropertyChanged("Cost");
                }
            }
        }


        private string currency;
        public string Currency
        {
            get { return currency; }
            set
            {
                if (currency != value)
                {
                    currency = value;
                    RaisePropertyChanged("Currency");
                }
            }
        }

        #endregion        

        private void RaisePropertyChanged(string property)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(property));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
