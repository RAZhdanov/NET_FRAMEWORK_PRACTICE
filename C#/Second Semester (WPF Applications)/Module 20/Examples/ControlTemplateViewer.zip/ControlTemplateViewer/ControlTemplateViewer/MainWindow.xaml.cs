﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Reflection;
using System.Xml;
using System.Windows.Markup;

namespace ControlTemplateViewer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Получение всех public и не abstract классов из сборки System.Windows.Controls
            Assembly assembly = Assembly.GetAssembly(typeof(Control));
            List<Type> types = new List<Type>();
            foreach (Type t in assembly.GetTypes())
            {
                if (t.IsSubclassOf(typeof(Control)) && !t.IsAbstract && t.IsPublic)
                {
                    types.Add(t);
                }
            }
            // Отображение списка типов в ListBox
            typeListBox.ItemsSource = types;
        }

        private void typeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            XmlWriterSettings settings = new XmlWriterSettings { Indent = true };
            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb, settings);

            try
            {
                // Создание и добавление элемента в Grid.
                // Это обходной путь, поскольку пока элемент не отображается у него свойство Template не заполнено
                Type type = typeListBox.SelectedItem as Type;
                Control control = (Control)Activator.CreateInstance(type);
                control.Visibility = Visibility.Collapsed; // Реально не отображаем элемент
                grid.Children.Add(control);

                // Сериализация в XAML свойства Template
                XamlWriter.Save(control.Template, writer);
                templateText.Text = sb.ToString();

                grid.Children.Remove(control);
            }
            catch
            {
                templateText.Text = "Невозможно добавить такой элемент в Grid";
            }
        }
    }
}
