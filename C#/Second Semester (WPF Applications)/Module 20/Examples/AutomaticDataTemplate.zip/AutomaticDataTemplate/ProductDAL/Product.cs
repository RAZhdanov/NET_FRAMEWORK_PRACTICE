﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ProductDAL
{
    public class Product
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageFilePath { get; set; }
        public decimal Cost { get; set; }
        public string Currency { get; set; }
    }
}
