﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConnectedLayer
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime? OrderDate { get; set; }
        public double? Freight { get; set; }
        public string ShipAddress { get; set; }
        public string ShipCity { get; set; }
        public string ShipCountry { get; set; }
        public string CompanyName { get; set; }
        public string ContactName { get; set; }
    }
}
