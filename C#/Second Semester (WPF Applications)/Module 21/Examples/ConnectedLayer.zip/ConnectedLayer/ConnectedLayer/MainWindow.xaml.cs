﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Data;
using System.Data.SqlClient;

namespace ConnectedLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Упрощенный вариант создания строки соединения
            SqlConnectionStringBuilder stringBuilder = new SqlConnectionStringBuilder();
            stringBuilder.DataSource = "(local)"; // адрес сервера
            stringBuilder.InitialCatalog = "Northwind"; // Имя базы данных
            //stringBuilder.IntegratedSecurity = true;
            stringBuilder.UserID = "student"; // логин
            stringBuilder.Password = "vmkstudent"; // пароль

            // Создание соединения
            SqlConnection connection = new SqlConnection(stringBuilder.ConnectionString);
            // открытие соединения
            connection.Open();

            // Создание команды
            SqlCommand command = new SqlCommand(
@"SELECT Ord.OrderID
      , Ord.OrderDate
      , Ord.Freight
      , Ord.ShipAddress
      , Ord.ShipCity
      , Ord.ShipCountry
      , Cust.CompanyName
      , Cust.ContactName
FROM Orders Ord JOIN Customers Cust 
      ON Ord.CustomerID = Cust.CustomerID", connection); // при создании комманды необходимо указать открытое соединение

            List<Order> orderList = new List<Order>();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Order order = new Order();
                    order.Id = reader.GetInt32(0);
                    order.OrderDate = (reader["OrderDate"] is DBNull) ? null : (DateTime?)reader["OrderDate"];
                    order.Freight = (reader["Freight"] is DBNull) ? null : (double?)Convert.ToDouble(reader["Freight"]);
                    order.ShipAddress = Convert.ToString(reader["ShipAddress"]);
                    order.ShipCity = Convert.ToString(reader["ShipCity"]);
                    order.ShipCountry = Convert.ToString(reader["ShipCountry"]);
                    order.CompanyName = Convert.ToString(reader["CompanyName"]);
                    order.ContactName = Convert.ToString(reader["ContactName"]);
                    orderList.Add(order);
                }
            }// Необходимо обязательно закрывать DataReader, т.е. вызывать reader.Close();
            // здесь используется using, и при вызове Dispose() при выходе из using Close() вызовется автоматически

            // Обязательно нужно закрывать соединение
            connection.Close();

            DataContext = orderList;
        }
    }
}
