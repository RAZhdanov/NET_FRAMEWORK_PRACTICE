﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace HandmadeDataSet
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание DataSet
            DataSet dataSet = new DataSet("FirstDataSet");

            // Создание и добавление таблицы
            DataTable createdTable = CreateDataTable();
            dataSet.Tables.Add(createdTable);

            // Получение сылки на таблицу Cars в DataSet - dataSet.Tables["Cars"]
            // Добавление строк в DataTable
            AddRowsToTable(dataSet.Tables["Cars"]);

            // Вывод DataSet на экран
            PrintDataSet(dataSet);

            // Демонстрация различных состояний и версий строк
            ShowDifferentRowStates(dataSet.Tables["Cars"]);

            Console.ReadKey();

        }

        /// <summary>
        /// Пример создания таблицы
        /// </summary>
        /// <returns>Созданная таблица</returns>
        static DataTable CreateDataTable()
        {
            // Создание и добавление таблицы
            DataTable table = new DataTable("Cars");

            // Создание, настройка и добавление колонок в таблицу
            DataColumn dc = new DataColumn("ID");
            dc.DataType = typeof(int);
            dc.AllowDBNull = false;
            dc.Unique = true;
            // AutoIncrement (аналог IDENTITY SQL Сервера)
            dc.AutoIncrement = true;
            dc.AutoIncrementSeed = -1; // -1 !!!! Для предотвращения конфликтов с IDENTITY полем SQL Сервера
            dc.AutoIncrementStep = -1; // -1 !!!! 
            table.Columns.Add(dc);

            dc = new DataColumn("Make");
            dc.DataType = typeof(string);
            dc.Caption = "Производитель";
            table.Columns.Add(dc);

            // Использование перегрузки конструктора
            dc = new DataColumn("Model", typeof(string));
            table.Columns.Add(dc);

            dc = new DataColumn("Cost", typeof(double));
            table.Columns.Add(dc);

            // Простой способ
            table.Columns.Add("IsSealed", typeof(bool));

            // Вычислимый столбец
            dc = new DataColumn("Discount", typeof(double));
            dc.Expression = "Cost * 0.85";
            table.Columns.Add(dc);

            // Еще Вычислимый столбец (не указанный тип столбца означает string)
            dc = new DataColumn("VendorAndType");
            dc.Expression = "Make + ' ' + Model"; // В стиле SQL
            table.Columns.Add(dc);

            // Создание Primary Key для таблицы (в  общем случае - набор колонок)
            table.PrimaryKey = new DataColumn[] { table.Columns["ID"] };

            return table;
        }

        /// <summary>
        /// Добавление строк в таблицу
        /// </summary>
        /// <param name="dt">Таблица</param>
        static void AddRowsToTable(DataTable dt)
        {
            // Получение прототипа строки
            DataRow row = dt.NewRow();
            // Запонение полей строки. Соблюдается контроль типов
            row["Make"] = "Hyndai";
            row[2] = "Accent"; // Можно обращаться по индексу столбца
            row["Cost"] = 500000;
            row["IsSealed"] = true;
            dt.Rows.Add(row);

            // Добавление еще одной строки (обратите внимание, не задана Cost, она по умолчанию DBNull)
            row = dt.NewRow();
            row["Make"] = "Toyota";
            row["Model"] = "Corola";
            row["IsSealed"] = false;
            dt.Rows.Add(row);

            // Другой способ добавления строки. Поскольку первый столбец AutoIncrement, то помещать в него явное значение нельзя - null
            dt.Rows.Add(null, "Kia", "Rio", 550000, false);
        }

        /// <summary>
        /// Распечатка DataSet
        /// </summary>
        /// <param name="ds">DataSet</param>
        /// <param name="allDataRowVersion">Распечатать все версии строк</param>
        private static void PrintDataSet(DataSet ds, bool allDataRowVersion = false)
        {
            foreach (DataTable dt in ds.Tables) // По всем таблицам в DataSet
            {
                Console.WriteLine("Таблица {0}", dt.TableName);
                if (allDataRowVersion) Console.Write("{0,-10}", "Версия");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    Console.Write("{0,-9}", dt.Columns[j].ColumnName);
                }
                Console.WriteLine();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (allDataRowVersion)
                    {
                        // Печать всех имеющихся на данный момент версий строк
                        foreach (DataRowVersion version in Enum.GetValues(typeof(DataRowVersion)))
                        {
                            if (dt.Rows[i].HasVersion(version))
                            {
                                Console.Write("{0,-10}", version);
                                for (int j = 0; j < dt.Columns.Count; j++)
                                    Console.Write("{0,-9}", dt.Rows[i][j, version]);
                                Console.WriteLine();
                            }
                        }
                    }
                    else
                        {// Печать всех default версий строк
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            Console.Write("{0,-9}", dt.Rows[i][j]);
                        }
                        Console.WriteLine();
                    }
                }
            }
        }

        /// <summary>
        /// Демонстрация различных состояний и версий строк
        /// </summary>
        /// <param name="dt">Таблица</param>
        static void ShowDifferentRowStates(DataTable dt)
        {
            Console.WriteLine("\nДемонстрация состояний строки:");
            // Работа с RowState
            DataRow dr = dt.Rows[0];
            Console.WriteLine(dr.RowState); // Строка только добавлена - Added

            dt.AcceptChanges();             // Применение изменений. Current row version -> Original row version
            Console.WriteLine(dr.RowState); // Теперь таже строка Unchanged

            dt.Rows[0]["Cost"] = 550000;
            Console.WriteLine(dr.RowState); // Теперь таже строка Modified

            dt.RejectChanges();             // Отмена изменений. Original row version -> Current row version
            Console.WriteLine(dr.RowState); // Теперь таже строка Unchanged

            dt.Rows[1]["Cost"] = 300;
            dt.Rows[1]["Model"] = "Королка";
            Console.WriteLine(dr.RowState); // Теперь таже строка Modified

            dr.Delete();                    // Пометка строки на удаление
            Console.WriteLine(dr.RowState); // Deleted

            Console.WriteLine("\nDataSet после удаления строки первой строки и изменения второй:");
            // Распечатаем все версии строк в DataSet
            PrintDataSet(dt.DataSet, true);
        }
    }
}
