﻿using System;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TableEditor
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private DataSet myDataSet;
        private SqlDataAdapter orderAdapter;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Создание DataSet
            myDataSet = new DataSet("MyDataSet");
            // Получение строки подключения к SQL серверу с именем "sqlProvider" из конфигурационного файла
            ConnectionStringSettings connectionString = ConfigurationManager.ConnectionStrings["sqlProvider"];
            // Создание адаптера. Заметьте, соединение явно не открывается и не закрывается
            orderAdapter = new SqlDataAdapter("select * from Orders", connectionString.ConnectionString);
            // построение Update, Insert, Delete команд по имеющейся SelectCommand
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(orderAdapter);

            DataTable orderTable = new DataTable("Orders");
            // Загрузка данных из базы в таблицу (соединение автоматически открывается, данные загружаются, соединение закрывается)
            orderAdapter.Fill(orderTable);
            myDataSet.Tables.Add(orderTable);

            DataContext = myDataSet;
        }

        private void Reject(object sender, RoutedEventArgs e)
        {
            // Отмена изменений с момента загрузки или последнего сохранения
            myDataSet.RejectChanges();
        }
        private void Save(object sender, RoutedEventArgs e)
        {
            // Сохранение данных в базе данных (соединение автоматически открывается, только измененные данные сохраняются, соединение закрывается)
            orderAdapter.Update(myDataSet.Tables["Orders"]);
        }
    }
}
