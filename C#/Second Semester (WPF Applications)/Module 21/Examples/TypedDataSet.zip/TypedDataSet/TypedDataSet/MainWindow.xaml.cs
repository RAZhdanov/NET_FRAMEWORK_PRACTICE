﻿using System;
using System.Windows;
using TypedDataSet.NorthwindDataSetTableAdapters;

namespace TypedDataSet
{
    /// <summary>
    /// Демонстрация работы с типизированным DataSet
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        NorthwindDataSet northwindDataSet = new NorthwindDataSet();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Создание типизированного DataSet
            northwindDataSet = new NorthwindDataSet();
            // Загрузка данных
            OrdersTableAdapter ordersAdapter = new OrdersTableAdapter();
            ordersAdapter.Fill(northwindDataSet.Orders);
            EmployeesTableAdapter EmployeesAdapter = new EmployeesTableAdapter();
            EmployeesAdapter.Fill(northwindDataSet.Employees);
            Order_DetailsTableAdapter orderDetailsTableAdapter = new Order_DetailsTableAdapter();
            orderDetailsTableAdapter.Fill(northwindDataSet.Order_Details);
            ProductsTableAdapter productsTableAdapter = new ProductsTableAdapter();
            productsTableAdapter.Fill(northwindDataSet.Products);
            DataContext = northwindDataSet;
        }

        private void Reject(object sender, RoutedEventArgs e)
        {
            northwindDataSet.RejectChanges();
        }
        private void Save(object sender, RoutedEventArgs e)
        {
            // Сохраняем только Orders и Order_Details. Продукты не сохраняем
            new OrdersTableAdapter().Update(northwindDataSet.Orders);
            new Order_DetailsTableAdapter().Update(northwindDataSet.Order_Details);
        }
    }
}
