﻿using System;
using System.Threading;

// Пример атомарных операций - класс Interlocked

namespace InterlockedDemo
{
    class Increment
    {
        long count = 0;
        public void Inc()
        {
            //for (int i = 0; i < 100000; ++i) count = count + 1; // выдаст непредсказуемые результаты
            
            //for (int i = 0; i < 100000; ++i) Interlocked.Increment(ref count); // Большие издержки на синхронизацию потоков
            
            long temp = 0L; // У каждого потока своя локальная переменная
            for (int i = 0; i < 100000; ++i) temp++; // Синхронизация потоков не нужна, у каждого потока своя переменная
            Interlocked.Add(ref count, temp); // атомарная операция сложения
            Console.WriteLine(count);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Increment i = new Increment();
            // Запуск 100 потоков
            for (int j = 0; j < 100; ++j) new Thread(i.Inc).Start();
            Console.ReadKey();
        }
    }
}
