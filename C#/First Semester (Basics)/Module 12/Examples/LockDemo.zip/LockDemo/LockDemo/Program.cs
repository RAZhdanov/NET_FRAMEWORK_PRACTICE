﻿using System;
using System.Threading;

// Пример синхронизации потоков с помощью инструкции lock

namespace LockDemo
{
    class Increment
    {
        // Объект для синхронизации
        // Единый для всех потоков !!!
        // Экземпляр ссылочного типа !!!
        // Не string !!!
        object lockObject = new object();

        long count = 0;
        public void Inc()
        {
            //for (int i = 0; i < 100000; ++i) count = count + 1; // выдаст непредсказуемые результаты

            // Большие издержки на синхронизацию потоков
            //for (int i = 0; i < 100000; ++i)
            //{
            //    lock (lockObject) // В этот блок одновременно может войти только один поток
            //    {
            //        count++;
            //    }
            //}

            long temp = 0L; // У каждого потока своя локальная переменная
            for (int i = 0; i < 100000; ++i) temp++; // Синхронизация потоков не нужна, у каждого потока своя переменная
            lock (lockObject) // В этот блок одновременно может войти только один поток
            {
                // Эксклюзивные действия. Единовременно здесь только один поток
                count += temp;
            }
            Console.WriteLine(count);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Increment i = new Increment();
            // Запуск 100 потоков
            for (int j = 0; j < 100; ++j) new Thread(i.Inc).Start();
            Console.ReadKey();
        }
    }
}
