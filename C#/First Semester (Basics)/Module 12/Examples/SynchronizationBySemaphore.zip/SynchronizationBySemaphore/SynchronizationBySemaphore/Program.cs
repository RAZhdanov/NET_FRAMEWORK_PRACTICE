﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

// Демонстрация синхронизации потоков даже между приложениями с использованием Семафора
// Для большего эффекта запускайте одновременно несколько экземпляров приложения

namespace SynchronizationBySemaphore
{
    class Program
    {
        const int numberOfTreads = 4;
        static Semaphore semaphore;

        static void Main(string[] args)
        {
            // Для удобства, если задан параметр командной строки, запускаем само приложение еще указанное кол-во раз
            if (args.Length > 0) TryToStartAdditionalProcesses(args[0]);

            using (semaphore = new Semaphore(3, 3, "SynchronizationSemaphore")) // Создается Семафор. Одновременно 3 потока смогут зайти в критическую секцию
            {
                List<Thread> threadList = new List<Thread>(numberOfTreads); // Сохраняем ссылки на потоки, чтобы потом корректно закрыть Semaphore (только, когда все работающие с Semaphore потоки будут завершены)
                for (int i = 0; i < numberOfTreads; i++)
                {
                    Thread t = new Thread(Work);
                    threadList.Add(t);
                    t.Start();
                }
                // Ожидание завершения всех дополнительных потоков
                foreach (Thread thread in threadList) thread.Join();
                Console.WriteLine("Программа закончила работу и ждет нажатия Enter для выхода");
                Console.ReadLine();
            } // Завершения работы с Semaphore и освобождение ресурсов Windows (вызов semaphore.Dispose())
        }

        static void Work()
        {
            for (int i = 0; i < 20; i++)
            {
                // Проверяем на свободность ресурсов Semaphore. Ожидаем его освобождения. При освобождении проходим внутрь и блокируем Semaphore (увеличиваем кол-во блокировок на 1)
                semaphore.WaitOne();
                Console.WriteLine("Работаю. Занимаю уникальный ресурс. Досчитал до {0}. Поток {1}", i, Thread.CurrentThread.ManagedThreadId);
                Thread.Sleep(500); // Эмулируем длительную работу
                semaphore.Release(); // Освобождение Semaphore (уменьшаем кол-во блокировок на 1)
            }
        }

        private static void TryToStartAdditionalProcesses(string commandLineParrameter)
        {
            int additionalProcessCount = 0;
            if (int.TryParse(commandLineParrameter, out additionalProcessCount))
            {
                string programName = Path.Combine(Environment.CurrentDirectory, "SynchronizationBySemaphore.exe");
                for (int i = 0; i < additionalProcessCount; i++) Process.Start(programName);
            }
        }
    }
}
