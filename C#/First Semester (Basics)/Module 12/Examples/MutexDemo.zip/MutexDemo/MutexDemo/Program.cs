﻿using System;
using System.Threading;

// Программа, допускающая запуск только одного экземпляра программы
// Запускайте одновременно несколько экземпляров программы (например, меню DEBUG -> Start Without Debugging, или Ctrl + F5)

namespace MutexDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Mutex mutex = new Mutex(false, "DemoMutex")) // Создание или получения от Windows именованного Mutex
            {
                // Ожидание освобождения Mutex (0 миллисекунд) и проход дальше с взведением Mutex
                // true - если Mutex не заблокирован
                // false - Mutex заблокирован и вышли по таймауту - 0 мс
                if (mutex.WaitOne(0))
                {
                    // Основной код программы
                    Console.WriteLine("Программа работает");
                    Console.WriteLine("Нажмите Enter для завершения программы\n");
                    // Рисуем "." пока пользователь не нажал ENTER
                    using (new Timer(o => Console.Write("."), null, 0, 1000)) Console.ReadLine();
                    // При выходе из программы освобождаем Mutex
                    mutex.ReleaseMutex();
                }
                else // Вышли по таймауту
                {
                    // Экземпляр программы уже запущен
                    Console.WriteLine("Программа уже запущена и поэтому будет закрыта");
                    Console.ReadLine();
                }
            }
        }
    }
}
