﻿using System;
using System.Diagnostics;
using System.IO;

// Пример запуска дополнительного процесса

namespace StartProcess
{
    class Program
    {
        static void Main(string[] args)
        {
            // Вычисляем путь к Paint
            string paintFile = Path.Combine(Environment.SystemDirectory, "mspaint.exe");
            // Запускаем Paint (новый процесс)
            Process process = Process.Start(paintFile);
            Console.WriteLine("Paint запущен");
            Console.WriteLine("Ждем его закрытия");
            // для примера, подождем закрытия Paint
            process.WaitForExit();
            Console.WriteLine("Paint закрыт пользователем");
            Console.WriteLine("Нажмите Enter для выхода из программы");
            Console.ReadLine();
        }
    }
}
