﻿using System;
using System.Threading;
using System.Threading.Tasks;

// Демонстрация синхронизации потоков даже между приложениями
// Запускайте одновременно несколько экземпляров приложения

namespace ProcessSynchronizationByMutex
{
    class Program
    {
        const int numberOfTreads = 4;
        static Mutex mutex;

        static void Main()
        {
            using (mutex = new Mutex(false, "ProcessSynchronizationMutex"))
            {
                Task[] tasks = new Task[numberOfTreads]; // Сохраняем ссылки на задачи, чтобы потом корректно закрыть Mutex (только, когда все работающие с Mutex потоки будут завершены)
                for (int i = 0; i < numberOfTreads; i++)
                {
                    Task t = new Task(Work);
                    tasks[i] = t;
                    t.Start();
                }

                Task.WaitAll(tasks); // Ожидание завершения всех заданий
                Console.WriteLine("Программа закончила работу и ждет нажатия Enter для выхода");
                Console.ReadLine();
            } // Завершения работы с Mutex и освобождение ресурсов Windows (вызов mutex.Dispose())
        }

        static void Work()
        {
            for (int i = 0; i < 10; i++)
            {
                // Проверяем на свободность Mutex. Ожидаем его освобождения. При освобождении проходим внутрь и блокируем Mutex
                mutex.WaitOne();
                Console.WriteLine("Работаю. Занимаю уникальный ресурс. Досчитал до {0}. Поток {1}", i, Thread.CurrentThread.ManagedThreadId);
                Thread.Sleep(500); // Эмулируем длительную работу
                mutex.ReleaseMutex(); // Освобождение Mutex
            }
        }
    }
}
