﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Encryption
{
    class Program
    {
        static void Main()
        {
            // Получение ключа и вектора инициализации. Только с целью демонстрации
            byte[] key, iv;
            using (Aes aesRoot = Aes.Create())
            {
                key = aesRoot.Key;
                iv = aesRoot.IV;
            }

            string fileName = Path.Combine(Environment.CurrentDirectory, "EncryptedText.txt");

            // Шифрование текста с помощью AES протокола
            using (Aes aes = Aes.Create())
            {
                // Задание ключей для шифрования
                aes.Key = key;
                aes.IV = iv;

                using (FileStream inStream = new FileStream(fileName, FileMode.Create))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(inStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cryptoStream))
                        {
                            sw.WriteLine("Hello");
                            sw.WriteLine("Hello again");
                        }
                    }
                }
            }

            Console.WriteLine($"Данные зашифрованы и сохранены в файле {fileName}");

            Console.WriteLine("Содержание файла:");
            Console.WriteLine(File.ReadAllText(fileName));
            Console.WriteLine();

            Console.WriteLine("Расшифровка данных из файла:");
            using (Aes aes = Aes.Create())
            {
                // Задание тех же ключей для расшифровки
                aes.Key = key;
                aes.IV = iv;

                // Расшифровка данных и распечатка их
                using (FileStream inStream = new FileStream(fileName, FileMode.Open))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(inStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (StreamReader sw = new StreamReader(cryptoStream))
                        {
                            while (!sw.EndOfStream)
                            {
                                Console.WriteLine(sw.ReadLine());
                            }
                        }
                    }
                }
            }

            Console.WriteLine();
            Console.WriteLine($"Для удаления временного файла нажмите enter ({fileName})");
            Console.ReadLine();

            try
            {
                File.Delete(fileName);
                Console.WriteLine($"Файл удален ({fileName})");
            }
            catch (Exception e) // Не важно по какой причине не удалось удалить. Оставляем файл.
            {
                Console.WriteLine($"Не удалось удалить файл {fileName}. Причина {e.Message}");
            }

            Console.ReadLine();
        }
    }
}
