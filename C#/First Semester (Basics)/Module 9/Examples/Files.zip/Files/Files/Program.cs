﻿using System;
using System.IO;

// Пример работы с файлами и файловой системой
// Типы:
// DirectoryInfo, Directory
// FileInfo, File
// DriveInfo
// Stream, FileStream, StreamReader, StreamWriter
// обладают большим количеством методов. Все варианты показать нереально. Экспериментируйте

namespace Files
{
    class Program
    {
        /// <summary>
        /// Распечатывает информацию о всех дисках
        /// </summary>
        private static void PrintAllDriveProperties()
        {
            DriveInfo[] drives = DriveInfo.GetDrives(); // Получение всех дисков
            foreach (DriveInfo d in drives)
            {
                Console.WriteLine("Name: {0}", d.Name);
                Console.WriteLine("Drive Type: {0}", d.DriveType);
                Console.WriteLine("Is Ready: {0}", d.IsReady);
                if (d.IsReady)
                {
                    Console.WriteLine("Volume Label: {0}", d.VolumeLabel);
                    Console.WriteLine("Drive Format: {0}", d.DriveFormat);
                    Console.WriteLine("Total Size: {0}", d.TotalSize);
                    Console.WriteLine("Available Free Space: {0}", d.AvailableFreeSpace);
                }
                Console.WriteLine();
            }
        }
        
        /// <summary>
        /// Распечатывает информацию о папке
        /// </summary>
        /// <param name="folder">Папка</param>
        private static void PrintFolderProperties(DirectoryInfo folder)
        {
            Console.WriteLine("Name: {0}", folder.Name);
            Console.WriteLine("Attributes: {0}", folder.Attributes);
            Console.WriteLine("Creation Time: {0}", folder.CreationTime);
            Console.WriteLine("Full Name: {0}{1}", folder.FullName, Environment.NewLine);
        }

        /// <summary>
        /// Распечатывает некоторую информацию о файле
        /// </summary>
        /// <param name="file">Файл</param>
        private static void PrintFileProperties(FileInfo file)
        {
            Console.WriteLine("Name: {0}", file.Name);
            Console.WriteLine("Attributes: {0}", file.Attributes);
            Console.WriteLine("Creation Time: {0}", file.CreationTime);
            Console.WriteLine("Length: {0}", file.Length);
            Console.WriteLine("Extension: {0}", file.Extension);
            Console.WriteLine("Full Name: {0}{1}", file.FullName, Environment.NewLine);
        }

        /// <summary>
        /// Создает и заполняет файлик (без обработки ошибок. Создает через File.Create())
        /// </summary>
        /// <param name="fullFileName">полное имя файла</param>
        private static void CreateAndFillNewFile(string fullFileName)
        {
            // см.также альтернативные варианты CreateAndFillNewFile2, CreateAndFillNewFile3

            FileStream fileStream = File.Create(fullFileName); // Создали как Create. 
            // Но с ним не очень удобно работать как с текстом (удобнее было бы создавать как CreateText()). Ничего, обернем
            StreamWriter sw = new StreamWriter(fileStream);
            // Заполняем файл
            sw.WriteLine("Тестовый файлик");
            sw.WriteLine("Содержит всякую белиберду");
            // Обязательно закрыть файл
            sw.Close(); // Поскольку это класс-обертка, то исходный Stream (fileStream) тоже при этом закроется

            // P.S. Немного глупая работа с файлом, но создано для демонстрации оборачиваемости потоков. Более менее грамотная работа показана в методе PrintFile()
            // P.S.S. Пропущена обработка ошибок try ... catch ... finaly ...
        }


        /// <summary>
        /// Создает и заполняет файлик
        /// Альтернативный вариант
        /// </summary>
        /// <param name="fullFileName">полное имя файла</param>
        private static void CreateAndFillNewFile2(string fullFileName)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(fullFileName);
                // Заполняем файл
                sw.WriteLine("Тестовый файлик");
                sw.WriteLine("Содержит всякую белиберду 2");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // Обязательно закрыть файл
                if (sw != null) sw.Close();
            }
        }

        /// <summary>
        /// Создает и заполняет файлик
        /// Альтернативный вариант
        /// </summary>
        /// <param name="fullFileName">полное имя файла</param>
        private static void CreateAndFillNewFile3(string fullFileName)
        {
            string text = "Тестовый файлик\nСодержит всякую белиберду 3";
            try
            {
                File.WriteAllText(fullFileName, text);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Распечатывает содержимое указанного файла
        /// </summary>
        /// <param name="fullFileName">Полное имя файла</param>
        private static void PrintFile(string fullFileName)
        {
            using (StreamReader sr = new StreamReader(fullFileName))
            {
                while (!sr.EndOfStream) Console.WriteLine(sr.ReadLine());
            } // sr.Close() будет автоматически вызван из метода Dispose при выходе из блока using { }
        }


        static void Main()
        {
            // Распечатка информации о всех дисках
            Console.WriteLine("Информация обо всех дисках:\n");
            PrintAllDriveProperties();

            Console.WriteLine("Нажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Распечатка информации о директории c:\Windows
            DirectoryInfo windowsFolder = new DirectoryInfo(@"c:\Windows");
            Console.WriteLine("Информация о директории c:\\Windows:");
            PrintFolderProperties(windowsFolder);

            Console.WriteLine("Нажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Распечатка информации о первых 5 поддиректорий c:\Windows
            Console.WriteLine("Информация о первых 5 поддиректориях папки c:\\Windows:\n");
            DirectoryInfo[] windowsSubFolders = windowsFolder.GetDirectories();
            for (int i = 0; i < windowsSubFolders.Length && i < 5; i++)
			{
                PrintFolderProperties(windowsSubFolders[i]);
			}

            Console.WriteLine("Нажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Распечатка информации о первых 5 .log файлах из папки c:\Windows
            Console.WriteLine("Информация о первых 5 .log файлах из папки c:\\Windows:\n");
            FileInfo[] filesInWindowsFolder = windowsFolder.GetFiles("*.log", SearchOption.TopDirectoryOnly);
            for (int i = 0; i < filesInWindowsFolder.Length && i < 5; i++)
            {
                PrintFileProperties(filesInWindowsFolder[i]);
            }

            Console.WriteLine("Нажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Создадим файл с именем delme.txt во временной директории
            string tempPath = Path.GetTempPath(); // Получили путь к временной директории (берет из настроек Windows)
            string fullFileName = Path.Combine(tempPath, "delme.txt");
            CreateAndFillNewFile(fullFileName);
            // Альтернативные варианты
            // CreateAndFillNewFile2(fullFileName);
            // CreateAndFillNewFile3(fullFileName);
            Console.WriteLine("Создали и заполнили файл: {0}", fullFileName);

            Console.WriteLine("Нажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Распечатаем на экране созданный файл
            Console.WriteLine("Распечатаем на экране созданный файл: {0}", fullFileName);
            PrintFile(fullFileName);

            Console.WriteLine("\nНажмите ENTER, чтобы продолжить\n");
            Console.ReadLine();

            // Удалим созданный нами временный файл
            Console.WriteLine("Удалим созданный нами временный файл: {0}", fullFileName);
            File.Delete(fullFileName);

            Console.WriteLine("Нажмите (почти) любую кнопку, чтобы выйти");
            Console.ReadKey();
        }
    }
}